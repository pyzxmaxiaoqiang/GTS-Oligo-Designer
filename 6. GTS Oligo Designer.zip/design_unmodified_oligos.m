function primers = design_unmodified_oligos(seq,name)

load('one2s.mat')  
seql = length(seq);
re2use = search_one2s(seq,one2s);
bestre = get_best(re2use);
if isempty(bestre) 
    bestre_name = [];
else
    bestre_name = bestre.name;
end
primers = proof_read(seq,name,bestre);

end

function primers = proof_read(seq,name,bestre)

n = 100;
for i=1:n
    primers = design_primers(seq,name,bestre,i);
    if ~isstruct(primers), return, end
    amplicon = primers.amplicon;
    amplicon = upper(amplicon);
    rsa = primers.rsa;
    k1 = strfind(amplicon,rsa);
    ampliconrc = seqrcomplement(amplicon);
    k2 = strfind(ampliconrc,rsa);
    k1l = length(k1);
    k2l = length(k2);
    if k1l + k2l ~= 2, continue, end
    flag = test_hairpin(primers);
    if ~flag, continue, end
    return
end
primers = [];

end

function flag = test_hairpin(primers)
flag = 1;
rsa = primers.rsa;
for_seq = primers.for_seq;
rev_seq = primers.rev_seq;
for_b = primers.for_b;
rev_b = primers.rev_b;
baseline_for = [rsa for_b];
hairpin = get_hairpin(baseline_for);
if ~isempty(hairpin)
    base = get_score(hairpin);
    hairpin = get_hairpin(for_seq);
    score = get_score(hairpin);
    if score - base ~= 0
        flag = 0; return
    end
end

baseline_rev = [rsa rev_b];
hairpin = get_hairpin(baseline_rev);
if ~isempty(hairpin)
    base = get_score(hairpin);
    hairpin = get_hairpin(rev_seq);
    score = get_score(hairpin);
    if score - base ~= 0
        flag = 0; return
    end
end

end

function hairpin = get_hairpin(seq)
prop = oligoprop(seq);
hairpin = prop.Hairpins;
if length(hairpin(:,1)) > 1
    hairpin = hairpin(1,:);
end
end

function score = get_score(seq)
seq2 = upper(seq);
k1 = length(seq);
score = 0;
for i=1:k1
    if strcmp(seq(i),seq2(i))
        score = score + 1;
    end
end

end

function primers = design_primers(seq,name,bestre,index)
primers = [];
if isempty(bestre)
    return
end

rsa = bestre.rsa;
rename = bestre.name;
spacer_lib = bestre.spacer_lib;
fs_lib = bestre.fs_lib;

if strcmpi(seq(1),'G') && strcmpi(seq(end),'T')
    binding = design_binding(seq);    
    spacer1 = lower(spacer_lib(index).spacer1);
    fs1 = fs_lib(index).fs1;
    primers.for_name = [name ' ' rename ' Foligo F'];
    primers.for_seq = [fs1 rsa spacer1 binding];
    primers.for_l = length([fs1 rsa spacer1 binding]);
    primers.for_b = binding;
    seqrc = seqrcomplement(seq);
    binding = design_binding(seqrc);
    spacer2 = lower(spacer_lib(index).spacer2);
    fs2 = fs_lib(index).fs2;
    primers.rev_name = [name ' ' rename ' Foligo R'];
    primers.rev_seq = [fs2 rsa spacer2 binding];
    primers.rev_l = length([fs2 rsa spacer2 binding]);
    primers.rev_b = binding;
    spacer2rc = seqrcomplement(spacer2);
    rsarc = seqrcomplement(rsa);
    fs2rc = seqrcomplement(fs2);
    amplicon = [fs1 rsa spacer1 seq spacer2rc rsarc fs2rc];
    primers.amplicon = amplicon;
    primers.seq = seq;
    primers.rsa = rsa;
else
    primers = 'The GT format is not met';
end

end

function binding = design_binding(geneseq)

for i=18:25
    binding = geneseq(1:i);
    prop = oligoprop(binding);
    tm = prop.Tm(6);
    if tm > 55
        break
    end
end
binding = upper(binding);
first = binding(1);
binding = [first lower(binding(2:end))];

end

function bestre = get_best(re2use)

bestre = [];
if isempty(re2use)
    return
end

[~,index] = sortrows([re2use.priority].'); 
re2use = re2use(index); 
clear index

bestre = re2use(1);

end

function re2use = search_one2s(seq,one2s)
re2use = one2s;
m = 1;
k1 = length(one2s);
seq = upper(seq);
seqrc = seqrcomplement(seq);
for i=1:k1
    rsa = one2s(i).rsa;
    if ~contains(seq,rsa) && ~contains(seqrc,rsa)
        re2use(m) = one2s(i);
        m = m + 1;
    end
end
re2use(m:end) = [];
if isempty(re2use)
    re2use = [];
end
end