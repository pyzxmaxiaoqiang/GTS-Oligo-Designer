function barcode = design_oligos_for_barcode(name,seq,se)

barcode = [];

if isempty(se)
    se = select_sticky_end(seq);
    if isempty(se), return, end
end

[left,se,right,seq] = get_left_right(se,seq);

barcode.name = name;
barcode.seq = seq;
barcode.left = left;
barcode.se = se;
barcode.right = right;
barcode = design_eight_oligos_for_barcode(barcode);

end

function newbarcode = design_eight_oligos_for_barcode(barcode)

    name = barcode.name;
    se = barcode.se;
    left = barcode.left;
    right = barcode.right;
    se = upper(se);
    seq = [left se right];
        
    left_r = seqrcomplement(left);
    se_r = seqrcomplement(se);

    slseq_left = design_barcode_primer(se_r,left_r);
    t_barcode.name = [name '-T-Barcode'];
    t_barcode.seq = [slseq_left 'A']; 
    c_barcode.name = [name '-C-Barcode'];
    c_barcode.seq = [slseq_left 'G'];
    
    slseq_right = design_barcode_primer(se,right);
    g_barcode.name = [name '-G-Barcode'];
    g_barcode.seq = [slseq_right 'G'];
    a_barcode.name = [name '-A-Barcode'];
    a_barcode.seq = [slseq_right 'A'];

    
    t_assemble.name = [name '-T-Assemble'];
    t_assemble.seq = design_assemble_primer(se_r,left_r,'A');
    c_assemble.name = [name '-C-Assemble'];
    c_assemble.seq = design_assemble_primer(se_r,left_r,'G');
    g_assemble.name = [name '-G-Assemble'];
    g_assemble.seq = design_assemble_primer(se,right,'G');
    a_assemble.name = [name '-A-Assemble'];
    a_assemble.seq = design_assemble_primer(se,right,'A');
    
    newbarcode = barcode;
    newbarcode.t_barcode = t_barcode;
    newbarcode.t_assemble = t_assemble;
    newbarcode.g_barcode = g_barcode;
    newbarcode.g_assemble = g_assemble;
    newbarcode.a_barcode = a_barcode;
    newbarcode.a_assemble = a_assemble;
    newbarcode.c_barcode = c_barcode;
    newbarcode.c_assemble = c_assemble;

end

function oligo = design_assemble_primer(se,side,the_nt)
k1 = length(se);
k1 = ceil(k1/2);
se1 = se(1:k1);
se2 = se(k1+1:end);
oligo = [se1 '*' se2 '*' side the_nt];
end

function [left,se,right,seq] = get_left_right(se,seq)
se = upper(se);
seq = upper(seq);
k2 = strfind(seq,se);
k3 = length(se);
left = lower(seq(1:k2-1));
right = lower(seq(k2+k3:end));
seq = [left se right];
end

function se = process_se(name,se,seq)
if isempty(se)
    se = select_sticky_end(seq);
    test_designed_se(name,se)
end
end

function test_designed_se(name,se)

if isempty(se)
    error(['Sticky end satisfying the condition cannot be found for ' ...
        name char(13) 'Replace or modify ' name ' and try again' ])   
end

end

function se = select_sticky_end(seq)
k1 = length(seq);
k2 = ceil(k1/2);
for i=0:k2
    k7 = k2 - i;
    se = generate_se(k7,seq);
    if ~isempty(se)
        return
    end
    k7 = k2 + i;
    se = generate_se(k7,seq);
    if ~isempty(se)
        return
    end   
end
end

function se = generate_se(k7,seq)
k1 = length(seq);
k3 = 7; 
k4 = 10;
for i=k3:k4
    if k7-i > 0 && k7+i <= k1
        se = seq(k7-i:k7+i);
        flag = test_se(se);
        if flag == 1, return, end
    end
    
    if k7-i-1 > 0 && k7+i <= k1
        se = seq(k7-i-1:k7+i);
        flag = test_se(se);
        if flag == 1, return, end
    end
    
    if k7-i-1 > 0 && k7+i+1 <= k1
        se = seq(k7-i:k7+i+1);
        flag = test_se(se);
        if flag == 1, return, end
    end
end
se = '';
end

function flag = test_se(se)
prop = oligoprop(se);
tm_all = prop.Tm;
tm = tm_all(6);
dimmers = prop.Dimers;
hairpins = prop.Hairpins;
flag = 0;
if tm > 50 && isempty(dimmers) && isempty(hairpins)
    flag = 1;
end
end

function slseq = design_barcode_primer(se,side)

load('loop_lib.mat');
k1 = length(loop_lib);
for i=1:k1
    loop = loop_lib{i,1};
    [flag, slseq] = design_barcode_primer_candidate( se, side, loop);
    if flag == 1, break, end
end

end

function [flag, seq] = design_barcode_primer_candidate( se, side, loop )

side = lower(side);
right_r = seqrcomplement(side);
se = upper(se); loop = lower(loop);
se_r = seqrcomplement(se);
seq = [right_r se_r loop se side];
sl1 = rnafold([seq 'A'], 'nogu',1);
sl2 = rnafold([seq 'T'], 'nogu',1);
sl3 = rnafold([seq 'C'], 'nogu',1);
sl4 = rnafold([seq 'G'], 'nogu',1);

k1 = length(side);
k2 = length(se);
k3 = k1+k2;
k4 = length(loop);

m = 1;
correct = '';
for i=1:k3
    correct(1,m) = '('; m = m+1;
end
for i=1:k4
    correct(1,m) = '.'; m = m+1;
end
for i=1:k3
    correct(1,m) = ')'; m = m+1;
end
correct(1,m) = '.';
flag = 0;
if strcmp(sl1, correct) && strcmp(sl2, correct) && ...
        strcmp(sl3, correct) && strcmp(sl4, correct), flag = 1; end

end



